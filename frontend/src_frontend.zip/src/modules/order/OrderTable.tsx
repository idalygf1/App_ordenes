// OrderTable.tsx
import React from 'react';
const OrderTable = () => {
  return <div>Tabla de Órdenes</div>;
};
export default OrderTable;
