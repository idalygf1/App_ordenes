// ProductTable.tsx
import React from 'react';
const ProductTable = () => {
  return <div>Tabla de Productos</div>;
};
export default ProductTable;
