import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Menu } from 'antd';
import routes from '../../routes';

function MenuDynamic() {
  const [menuItems, setMenuItems] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  const fakeMenuData = [
    {
      title: 'Dashboard',
      path: '/dashboard',
      roles: ['665a1f2b04fd3a1b23e7761f'],
    },
    {
      title: 'Usuarios',
      path: '/users',
      roles: ['665a1f2b04fd3a1b23e7761f'],
    },
    {
      title: 'Productos',
      path: '/products',
      roles: ['665a1f2b04fd3a1b23e7761f', '665a1f2b04fd3a1b23e7761f2'],
    },
    {
      title: 'Ordenes',
      path: '/orders',
      roles: ['665a1f2b04fd3a1b23e7761f', '665a1f2b04fd3a1b23e7761f2'],
    },
  ];

  useEffect(() => {
    setTimeout(() => {
      setMenuItems(routes);
    }, 500);
  }, []);

  const renderMenu = () => {
  return menuItems
    .filter((item) => !item.hidden)
    .map((item) => ({
      key: item.path,
      icon: item.icon || null,
      label: item.label,
    }));
};


  return (
    <Menu
      theme="dark"
      mode="inline"
      selectedKeys={[location.pathname]}
      onClick={({ key }) => navigate(key)}
      items={renderMenu()}
    />
  );
}

export default MenuDynamic;
